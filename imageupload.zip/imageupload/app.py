from flask import Flask,render_template,request,redirect,flash
from sqlite3 import connect,Row
database:str = "imageupload.db"
########################################################
def postprocess(sql:str)->bool:
    db=connect(database)
    cursor=db.cursor()
    cursor.execute(sql)
    db.commit()
    db.close()
    return True if cursor.rowcount>0 else False

def getprocess(sql:str)->list:
    db=connect(database)
    cursor=db.cursor()
    db.row_factory = Row
    cursor.execute(sql)
    data:list = cursor.fetchall()
    return data

def add_student(**kwargs)->bool:
    keys:list = list(kwargs.keys())
    values:list = list(kwargs.values())
    flds:str = "`,`".join(keys)
    vals:str = "','".join(values)
    sql:str = f"INSERT INTO `students` (`{flds}`) VALUES('{vals}')"
    return postprocess(sql)

def get_students()->list:
    sql:str = f"SELECT * FROM `students`"
    return getprocess(sql)







#########################################################

app = Flask(__name__)

uploadfolder:str = "static/images/students"
app.config['UPLOAD_FOLDER'] = uploadfolder
app.config['SECRET_KEY'] = "secretkey!@#$##$%%$"

@app.route("/saveinformation", methods=['POST'])

def saveinformation()->None:
    idno:str = request.form['idno']
    lastname:str = request.form['lastname']
    firstname:str = request.form['firstname']
    course:str = request.form['course']
    level:str = request.form['level']

    file = request.files['imageupload']
    filename = uploadfolder+"/"+file.filename
    file.save(filename)
    ok:bool = add_student(idno=idno,lastname=lastname,firstname=firstname,course=course,level=level,image=filename)
    if ok: flash("New Student Added")
    return redirect("/")



@app.route("/")
def index()->None:
    return render_template("index.html", pagetitle = "STUDENT REGISTRATION",)

if __name__=="__main__":
    app.run(debug = True)
